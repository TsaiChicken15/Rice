package rice.jui;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

import net.minecraft.util.ResourceLocation;

public class JMain {
	
	public static void setup() {

		new JClickGUI();
		new JArrayList();
		
	}
}
